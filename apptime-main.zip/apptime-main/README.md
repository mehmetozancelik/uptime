<p align="center">
  <img width="100" src="https://raw.githubusercontent.com/elevenvac/elevenvac/master/Eleven_icon_higer_florence.png" alt="Eleven Icon">
</p>

## Description
⚡ Advanced Open-source Free Monitoring Service. (not lastest version)

## Programming Languages
`EJS`, `JavaScript` & `CSS`

## Contributors
Thanks for contributions: `cenapyuce`

## Installation
- npm i
- node server.js

## Discord Server
<a href="https://discord.gg/P578T3aYbj"><img src="http://invidget.switchblade.xyz/HWjPAAs9d3"/></a>
